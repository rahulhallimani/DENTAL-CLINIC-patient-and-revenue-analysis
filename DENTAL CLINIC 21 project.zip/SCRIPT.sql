sELECT clinic_id, sum(revenues) as Total_Revenue_2022, COUNT(DISTINCT patient_id) as Unique_Patients_2022
FROM sakila.p21_bi_intern_test_appointments
inner join sakila.p21_bi_intern_test_revenues using (appointment_id)
WHERE appointment_date >= '2022-01-01' AND appointment_date <= '2022-12-31'
GROUP BY clinic_id;

select sum(revenue),appointment_month 
from sakila.dental_clinic_21
group by appointment_month
order by appointment_month desc;

select sum(revenue),appointment_month,clinic_id
from sakila.dental_clinic_21
group by clinic_id,appointment_month
order by appointment_month desc;

SELECT COUNT(DISTINCT patient_id) as monthly_Unique_Patients_2022,appointment_month
FROM sakila.dental_clinic_21
GROUP BY appointment_month
order by appointment_month;

SELECT COUNT(DISTINCT patient_id) as monthly_Unique_Patients_2022,appointment_month,clinic_id
FROM sakila.dental_clinic_21
GROUP BY appointment_month,clinic_id
order by appointment_month;

select avg(revenue),appointment_month
from sakila.dental_clinic_21
group by appointment_month
order by appointment_month desc;

select avg(revenue),appointment_month,clinic_id
from sakila.dental_clinic_21
group by clinic_id,appointment_month
order by appointment_month;




